@extends('layouts.app')

@section('title', 'About')

@section('content')

<div class="container mt-4">
    <h1>About</h1>
</div>

@endsection