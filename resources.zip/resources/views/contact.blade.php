@extends('layouts.app')

@section('title', 'Contact')

@section('content')

<div class="container mt-4">
    <h1>Contact</h1>
</div>

@endsection