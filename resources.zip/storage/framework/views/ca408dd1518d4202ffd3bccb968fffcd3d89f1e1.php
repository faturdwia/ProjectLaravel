

<?php $__env->startSection('title', $post->title); ?>

<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    <h3><?php echo e($post->title); ?></h3>
    <div class="text-secondary">
        <a href="<?php echo e(route('categories.index', $post->category->slug)); ?>" class="text-decoration-none"><?php echo e($post->category->name); ?> </a>
        &middot; 
        <?php echo e($post->created_at->format("d F, Y")); ?>

        &middot;
        <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('tags.index', $tag->slug)); ?>" class="text-decoration-none"><?php echo e($tag->name); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <hr>
    <p><?php echo e($post->body); ?></p>
    <div class="text-secondary mb-3">Posted by <?php echo e($post->author->name); ?></div>
    <div class="">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $post)): ?>
            <!-- Button trigger modal -->
            <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#exampleModal">
            Delete
            </button>

        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Are you sure want to delete this post?</h5>
                    <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <?php echo e($post->title); ?> will be deleted.
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <form action="<?php echo e(route('posts.delete', $post->slug)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button class="btn btn-danger">Delete</button>
                    </form>
                </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Learning Path\Laravel - Parsinta\Laravel7\resources\views/posts/show.blade.php ENDPATH**/ ?>