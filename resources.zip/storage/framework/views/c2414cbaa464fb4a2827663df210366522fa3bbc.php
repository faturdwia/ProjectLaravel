

<?php $__env->startSection('title', 'Create Post'); ?>

<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    <h3 class="mb-4">Create Post</h3>
    <form class="col-md-6" method="POST" action="<?php echo e(route('posts.store')); ?>">
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('posts.partial.form-control', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Learning Path\Laravel - Parsinta\Laravel7\resources\views/posts/create.blade.php ENDPATH**/ ?>