

<?php $__env->startSection('title', 'Post'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="d-flex justify-content-between">
        <h3 class=""><?php echo e(isset($category) ? 'Category : ' . $category->name : (isset($tag) ? 'Tag : ' . $tag->name : 'All Post')); ?></h3>
        <div>
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-primary">Create Post</a>
            <?php endif; ?>
            <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(route('login')); ?>" class="btn btn-light">Login to Create</a>
            <?php endif; ?>
        </div>
    </div>
    <hr>
    <?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 mb-4">
            <div class="card h-100">
                <div class="card-header">
                    <?php echo e($item->title); ?>

                </div>
                <div class="card-body">
                    <p class="card-text"><?php echo e(Str::limit($item->body, 100, '...')); ?></p>
                    <a href="<?php echo e(route('posts.show', $item->slug)); ?>" class="">Read more</a>
                </div>
                <div class="card-footer d-flex justify-content-between">
                    Published on <?php echo e($item->created_at->diffForHumans()); ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $item)): ?>
                    <a href="<?php echo e(route('posts.edit', $item->slug)); ?>" class="btn btn-sm btn-success">Edit</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="d-flex justify-content-center mt-4">
        <?php echo e($post->links()); ?>

    </div>
    </div>
    
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Learning Path\Laravel - Parsinta\Laravel8\resources\views/posts/index.blade.php ENDPATH**/ ?>