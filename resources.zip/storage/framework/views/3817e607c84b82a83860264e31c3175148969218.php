<div class="row">
    <div class="col-md-6">
        <div class="alert alert-<?php echo $__env->yieldContent('status'); ?> alert-dismissible fade show" role="alert">
            <?php echo e(session()->get("<?php echo $__env->yieldContent('status'); ?>")); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    </div>
</div><?php /**PATH F:\Learning Path\Laravel - Parsinta\Laravel8\resources\views/layouts/alert-item.blade.php ENDPATH**/ ?>